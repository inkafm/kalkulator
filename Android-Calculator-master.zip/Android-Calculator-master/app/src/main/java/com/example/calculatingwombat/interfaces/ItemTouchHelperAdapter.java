package com.example.calculatingwombat.interfaces;

public interface ItemTouchHelperAdapter {
    void onItemMove(int from, int to);
    void onItemSwipe(int index);
}
